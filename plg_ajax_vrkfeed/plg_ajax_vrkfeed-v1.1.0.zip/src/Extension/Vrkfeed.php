<?php
/**
 * Ajax — VRK News: поэтапная установка.
 *
 * Пакет выпуска VRK News, установленный из админки при включённом этом плагине, делает только подготовку (метки, поля) и
 * записывает задание administrator/manifests/packages/<пакет>/vrkfeed-job.json. Этот плагин показывает страницу хода
 * установки и ставит материалы по одному за запрос, с паузой между ними, чтобы сайт не подвисал (решение редактора 24.11.2026).
 *
 *   страница:  administrator/index.php?option=com_ajax&group=ajax&plugin=vrkfeed&format=raw&act=page&pkg=vrknewsfeed_ГГГГММДД[NN]
 *   шаг:       … &act=step&pkg=…&<токен>=1  → JSON {k, total, done, title, messages}
 *
 * Логика установки живёт в самом пакете выпуска (его script.php в каталоге манифестов): плагин лишь вызывает его методы step()
 * и finish(). Доступ — только в админке, пользователю с правом управлять расширениями, шаг — с проверкой токена формы.
 *
 * Установка без админки (с 1.1.0, выключена по умолчанию): сайт принимает подписанные команды на
 *   POST index.php?option=com_ajax&group=ajax&plugin=vrkfeed&format=raw   (поля payload и sig)
 * payload — JSON {v:1, act: install|step|status, site, ts, nonce, url?, sha256?, pkg?}, sig — подпись Ed25519 строки payload
 * в base64. Сайт хранит только открытые ключи (настройка «Ключи»): украденная база не даёт подделать команду. Отсекаются
 * чужой сайт, запрос старше пяти минут, повтор nonce, адрес пакета вне открытой копии wmarka-updates, файл с другим хэшем
 * и пакет, который не является пакетом выпуска vrknewsfeed. Клиент — tools/remote_install.py.
 */

namespace Wmarka\Plugin\Ajax\Vrkfeed\Extension;

\defined('_JEXEC') or die;

use Joomla\CMS\Installer\Installer;
use Joomla\CMS\Installer\InstallerHelper;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;
use Joomla\Event\Event;
use Joomla\Event\SubscriberInterface;

final class Vrkfeed extends CMSPlugin implements SubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return ['onAjaxVrkfeed' => 'onAjaxVrkfeed'];
    }

    public function onAjaxVrkfeed(Event $event): void
    {
        $app = $this->getApplication();
        $act = $app->getInput()->getCmd('act', 'page');

        if ($app->isClient('site') && $app->getInput()->getMethod() === 'POST' && $app->getInput()->post->get('sig', '', 'raw') !== '') {
            $this->remote();
        }

        if (!$app->isClient('administrator')) {
            $this->out(403, 'Только в панели управления.', $act);
        }

        $user = $app->getIdentity();

        if (!$user || !$user->id || !$user->authorise('core.manage', 'com_installer')) {
            $this->out(403, 'Нет прав на установку расширений.', $act);
        }

        $pkg = $app->getInput()->getCmd('pkg', '');

        if (!preg_match('/^vrknewsfeed_\d{8,10}$/', $pkg)) {
            $this->out(400, 'Неверное имя пакета.', $act);
        }

        $dir  = JPATH_ADMINISTRATOR . '/manifests/packages/' . $pkg;
        $file = $dir . '/vrkfeed-job.json';

        if (!is_file($file) || !is_file($dir . '/script.php')) {
            $this->out(404, 'Задание поэтапной установки для ' . $pkg . ' не найдено: установите пакет выпуска из админки при включённом плагине.', $act);
        }

        $job = json_decode((string) file_get_contents($file), true);

        if (!\is_array($job) || empty($job['class']) || empty($job['data']['items'])) {
            $this->out(500, 'Задание повреждено: ' . $file, $act);
        }

        if ($act === 'step') {
            if (!Session::checkToken('get')) {
                $this->out(403, 'Сессия устарела: обновите страницу.', $act);
            }

            $this->step($job, $file, $dir);
        }

        $this->page($pkg, $job);
    }

    /** Один шаг: следующий материал или завершение */
    private function step(array $job, string $file, string $dir): void
    {
        $this->json($this->runStep($job, $file, $dir));
    }

    /** Выполняет шаг задания и возвращает ответ: {k, total, done, title, error, messages} или {busy: true, …} */
    private function runStep(array $job, string $file, string $dir): array
    {
        $fp = fopen($file . '.lock', 'c');

        if ($fp === false || !flock($fp, LOCK_EX | LOCK_NB)) {
            return ['busy' => true, 'k' => (int) $job['next'], 'total' => \count($job['data']['items']), 'done' => false, 'messages' => []];
        }

        // задание перечитывается под замком: параллельный шаг мог его уже сдвинуть
        $fresh = json_decode((string) file_get_contents($file), true);

        if (\is_array($fresh) && !empty($fresh['data']['items'])) {
            $job = $fresh;
        }

        require_once $dir . '/script.php';
        $cls   = (string) $job['class'];
        $imp   = new $cls($job['data'], false);
        $total = \count($job['data']['items']);
        $k     = (int) $job['next'];
        $title = '';

        if (!empty($job['done'])) {
            $msgs = [];
        } elseif ($k < $total) {
            $title         = (string) ($job['data']['items'][$k]['text']['ru-RU']['title'] ?? '');
            $job['stats']  = $imp->step($k, (array) $job['stats']);
            $msgs          = $imp->takeMessages();
            $job['next']   = $k + 1;
        } else {
            $imp->finish((array) $job['stats']);
            $msgs        = $imp->takeMessages();
            $job['done'] = true;
            $job['finished'] = gmdate('Y-m-d H:i:s');
        }

        $errors = array_values(array_filter($msgs, static fn ($m) => $m[0] === 'error'));
        // служебная строка «№NN: {номера статей}» в ходе установки не нужна редактору
        $msgs = array_values(array_filter($msgs, static fn ($m) => $m[0] === 'error' || !preg_match('/^№\d+: \{/u', (string) $m[1])));

        if ($errors === []) {
            file_put_contents($file, json_encode($job, JSON_UNESCAPED_UNICODE));
        }

        flock($fp, LOCK_UN);
        fclose($fp);

        return ['k' => (int) $job['next'], 'total' => $total, 'done' => !empty($job['done']), 'title' => $title,
            'error' => $errors !== [], 'messages' => array_map(static fn ($m) => $m[1], $msgs)];
    }

    private function json(array $data): void
    {
        $app = $this->getApplication();
        $app->setHeader('Content-Type', 'application/json; charset=utf-8', true);
        $app->setHeader('Cache-Control', 'no-store', true);
        $app->sendHeaders();
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        $app->close();
    }

    private function out(int $code, string $text, string $act): void
    {
        $app = $this->getApplication();
        $app->setHeader('Status', (string) $code, true);

        if ($act === 'step') {
            $this->json(['error' => true, 'fatal' => true, 'messages' => [$text]]);
        }

        $app->sendHeaders();
        echo '<!doctype html><meta charset="utf-8"><title>VRK News</title><p style="font:16px sans-serif;margin:2em">' . htmlspecialchars($text) . '</p>';
        $app->close();
    }

    // ---------- установка без админки: подписанные команды ----------

    /** Адрес открытой копии пакета: …/releases/download/vrknews-issue-ДАТА[-N]-vX.Y.Z/pkg_vrknewsfeed_ГГГГММДД[NN]-vX.Y.Z.zip */
    private const URL_TAIL = '#^issue-(\d{4})-(\d{2})-(\d{2})(?:-(\d{1,2}))?-v(\d+\.\d+\.\d+)/pkg_vrknewsfeed_(\d{8}(?:\d{2})?)-v(\d+\.\d+\.\d+)\.zip$#';
    private const DEFAULT_PREFIX = 'https://github.com/bsakhanov/wmarka-updates/releases/download/vrknews-';
    private const MAX_BYTES = 64 * 1024 * 1024;
    private const WINDOW = 300;

    private function remote(): void
    {
        $app = $this->getApplication();
        Log::addLogger(['text_file' => 'vrkfeed-remote.php'], Log::ALL, ['vrkfeed-remote']);
        $ip = (string) $app->getInput()->server->getString('REMOTE_ADDR', '');

        if (!(int) $this->params->get('remote_enabled', 0)) {
            $this->rjson(403, ['error' => true, 'messages' => ['Установка без админки выключена в настройках плагина.']]);
        }

        $ips = array_filter(array_map('trim', preg_split('/[\s,]+/', (string) $this->params->get('remote_ips', ''))));

        if ($ips !== [] && !\in_array($ip, $ips, true)) {
            $this->audit('отказ: адрес ' . $ip . ' не в списке');
            $this->rjson(403, ['error' => true, 'messages' => ['Адрес отправителя не разрешён.']]);
        }

        $payload = (string) $app->getInput()->post->get('payload', '', 'raw');
        $sig     = base64_decode((string) $app->getInput()->post->get('sig', '', 'raw'), true);

        if ($payload === '' || \strlen($payload) > 4096 || $sig === false || \strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES || !$this->verify($payload, $sig)) {
            $this->audit('отказ: подпись не сошлась, адрес ' . $ip);
            $this->rjson(403, ['error' => true, 'messages' => ['Подпись команды не подтверждена.']]);
        }

        $cmd  = json_decode($payload, true);
        $host = strtolower(preg_replace('/^www\./', '', (string) Uri::getInstance()->getHost()));

        if (!\is_array($cmd) || ($cmd['v'] ?? null) !== 1 || !\is_string($cmd['act'] ?? null) || !\is_int($cmd['ts'] ?? null)
            || !\is_string($cmd['nonce'] ?? null) || !preg_match('/^[0-9a-f]{32}$/', $cmd['nonce'])) {
            $this->rjson(400, ['error' => true, 'messages' => ['Команда повреждена.']]);
        }

        if (strtolower(preg_replace('/^www\./', '', (string) ($cmd['site'] ?? ''))) !== $host) {
            $this->audit('отказ: команда для сайта ' . ($cmd['site'] ?? '?') . ', а это ' . $host);
            $this->rjson(403, ['error' => true, 'messages' => ['Команда подписана для другого сайта.']]);
        }

        if (abs(time() - $cmd['ts']) > self::WINDOW) {
            $this->rjson(403, ['error' => true, 'messages' => ['Команда устарела: часы отправителя и сайта расходятся больше чем на 5 минут.']]);
        }

        if (!$this->useNonce($cmd['nonce'])) {
            $this->audit('отказ: повтор команды ' . $cmd['nonce']);
            $this->rjson(403, ['error' => true, 'messages' => ['Команда уже выполнялась (повтор).']]);
        }

        @set_time_limit(300);

        switch ($cmd['act']) {
            case 'install':
                $this->remoteInstall($cmd, $ip);
                // no break: remoteInstall отвечает сам
            case 'step':
            case 'status':
                $pkg = (string) ($cmd['pkg'] ?? '');

                if (!preg_match('/^vrknewsfeed_\d{8,10}$/', $pkg)) {
                    $this->rjson(400, ['error' => true, 'messages' => ['Неверное имя пакета.']]);
                }

                $dir  = JPATH_ADMINISTRATOR . '/manifests/packages/' . $pkg;
                $file = $dir . '/vrkfeed-job.json';
                $job  = is_file($file) ? json_decode((string) file_get_contents($file), true) : null;

                if (!\is_array($job) || empty($job['data']['items']) || !is_file($dir . '/script.php')) {
                    $this->rjson(404, ['error' => true, 'messages' => ['Задания поэтапной установки для ' . $pkg . ' нет.']]);
                }

                if ($cmd['act'] === 'status') {
                    $this->rjson(200, $this->jobState($job));
                }

                $res = $this->runStep($job, $file, $dir);
                $res['pause'] = max(0, min(60, (int) $this->params->get('pause', 2)));

                if (!empty($res['done']) && empty($res['busy'])) {
                    $this->audit('выпуск ' . $pkg . ': поэтапная установка завершена, адрес ' . $ip);
                } elseif (!empty($res['error'])) {
                    $this->audit('выпуск ' . $pkg . ': ошибка на шаге ' . ((int) $job['next'] + 1) . ': ' . implode(' | ', $res['messages']));
                }

                $this->rjson(200, $res);
        }

        $this->rjson(400, ['error' => true, 'messages' => ['Неизвестная команда.']]);
    }

    private function verify(string $payload, string $sig): bool
    {
        foreach (preg_split('/\s+/', trim((string) $this->params->get('remote_keys', ''))) as $line) {
            $key = base64_decode($line, true);

            if ($key !== false && \strlen($key) === SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES && sodium_crypto_sign_verify_detached($sig, $payload, $key)) {
                return true;
            }
        }

        return false;
    }

    /** Одноразовый номер команды: повтор той же подписанной команды отклоняется */
    private function useNonce(string $nonce): bool
    {
        $file = rtrim((string) $this->getApplication()->get('tmp_path', JPATH_ROOT . '/tmp'), '/') . '/vrkfeed-remote-nonces.json';
        $fp   = fopen($file, 'c+');

        if ($fp === false || !flock($fp, LOCK_EX)) {
            return false;
        }

        $seen = json_decode((string) stream_get_contents($fp), true) ?: [];
        $now  = time();
        $seen = array_filter((array) $seen, static fn ($t) => $now - (int) $t < 2 * self::WINDOW);
        $ok   = !isset($seen[$nonce]);
        $seen[$nonce] = $now;
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($seen));
        flock($fp, LOCK_UN);
        fclose($fp);

        return $ok;
    }

    private function jobState(array $job): array
    {
        return ['k' => (int) $job['next'], 'total' => \count($job['data']['items']), 'done' => !empty($job['done']),
            'issue' => (string) ($job['issue'] ?? ''), 'prepared' => (string) ($job['prepared'] ?? ''), 'finished' => (string) ($job['finished'] ?? ''),
            'error' => false, 'messages' => []];
    }

    /** Скачивает пакет из открытой копии, сверяет хэш и состав, ставит его установщиком Joomla */
    private function remoteInstall(array $cmd, string $ip): void
    {
        $app    = $this->getApplication();
        $url    = (string) ($cmd['url'] ?? '');
        $sha    = strtolower((string) ($cmd['sha256'] ?? ''));
        $prefix = (string) $this->params->get('remote_prefix', self::DEFAULT_PREFIX) ?: self::DEFAULT_PREFIX;

        if (strncmp($url, $prefix, \strlen($prefix)) !== 0 || !preg_match(self::URL_TAIL, substr($url, \strlen($prefix)), $m)
            || $m[1] . $m[2] . $m[3] . ($m[4] !== '' ? sprintf('%02d', (int) $m[4]) : '') !== $m[6] || $m[5] !== $m[7]) {
            $this->audit('отказ: адрес пакета вне открытой копии: ' . $url);
            $this->rjson(400, ['error' => true, 'messages' => ['Адрес пакета не из открытой копии выпусков: ' . $url]]);
        }

        if (!preg_match('/^[0-9a-f]{64}$/', $sha)) {
            $this->rjson(400, ['error' => true, 'messages' => ['Нет хэша SHA-256 пакета.']]);
        }

        $element = 'vrknewsfeed_' . $m[6];
        $tmp     = rtrim((string) $app->get('tmp_path', JPATH_ROOT . '/tmp'), '/');
        $lock    = fopen($tmp . '/vrkfeed-remote-install.lock', 'c');

        if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
            $this->rjson(409, ['busy' => true, 'error' => true, 'messages' => ['Сайт уже ставит пакет: повторите позже.']]);
        }

        $zip = $tmp . '/vrkfeed-remote-' . bin2hex(random_bytes(6)) . '.zip';

        try {
            $body = $this->download($url);

            if (!hash_equals($sha, hash('sha256', $body))) {
                throw new \RuntimeException('хэш скачанного пакета ' . hash('sha256', $body) . ' не совпал с подписанным ' . $sha);
            }

            file_put_contents($zip, $body);
            unset($body);
            $this->checkPackage($zip, $element);
            $pk = InstallerHelper::unpack($zip, true);

            if (!$pk || ($pk['type'] ?? '') !== 'package') {
                throw new \RuntimeException('архив не распознан установщиком Joomla как пакет');
            }

            $app->getLanguage()->load('com_installer', JPATH_ADMINISTRATOR);
            $installer = Installer::getInstance();
            $ok        = $installer->install($pk['dir']);
            InstallerHelper::cleanupInstall($zip, $pk['extractdir']);
            $msgs = [];

            foreach ($app->getMessageQueue(true) as $q) {
                $msgs[] = trim(html_entity_decode(strip_tags((string) $q['message']), ENT_QUOTES, 'UTF-8'));
            }

            $file = JPATH_ADMINISTRATOR . '/manifests/packages/' . $element . '/vrkfeed-job.json';
            $job  = is_file($file) ? json_decode((string) file_get_contents($file), true) : null;
            // staged: пакет только подготовил задание, материалы ставятся командами step; иначе он поставил всё сразу
            $res = array_merge(\is_array($job) ? $this->jobState($job) : [], ['installed' => (bool) $ok, 'pkg' => $element, 'error' => !$ok,
                'staged' => \is_array($job) && empty($job['done']), 'messages' => array_values(array_filter($msgs))]);
            $this->audit('выпуск ' . $element . ': пакет ' . basename($url) . ' (' . $sha . ') ' . ($ok ? 'поставлен' : 'не поставлен') . ', адрес ' . $ip);
        } catch (\Throwable $e) {
            is_file($zip) && @unlink($zip);
            $this->audit('выпуск ' . $element . ': ошибка установки: ' . $e->getMessage());
            $res = ['installed' => false, 'pkg' => $element, 'error' => true, 'messages' => ['Пакет не поставлен: ' . $e->getMessage()]];
        }

        flock($lock, LOCK_UN);
        fclose($lock);
        $this->rjson(200, $res);
    }

    /** Скачивание только по https и только с GitHub (переадресация на хранилище файлов GitHub разрешена) */
    private function download(string $url): string
    {
        $hosts = ['github.com', 'objects.githubusercontent.com', 'release-assets.githubusercontent.com'];

        for ($hop = 0; $hop < 6; $hop++) {
            $u = parse_url($url);

            if (($u['scheme'] ?? '') !== 'https' || !\in_array(strtolower((string) ($u['host'] ?? '')), $hosts, true)) {
                throw new \RuntimeException('переадресация на чужой адрес: ' . $url);
            }

            $ch = curl_init($url);
            $hdr = [];
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_TIMEOUT => 180, CURLOPT_CONNECTTIMEOUT => 20,
                CURLOPT_USERAGENT => 'vrkfeed-remote/1.1', CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_HEADERFUNCTION => static function ($c, $h) use (&$hdr) {
                    if (preg_match('/^location:\s*(\S+)/i', $h, $mm)) {
                        $hdr['location'] = $mm[1];
                    }

                    return \strlen($h);
                },
                CURLOPT_NOPROGRESS => false,
                CURLOPT_XFERINFOFUNCTION => static fn ($c, $dlTotal, $dl) => ($dl > self::MAX_BYTES || $dlTotal > self::MAX_BYTES) ? 1 : 0]);
            $body = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $err  = curl_error($ch);
            curl_close($ch);

            if ($body === false) {
                throw new \RuntimeException('пакет не скачался: ' . $err);
            }

            if ($code >= 300 && $code < 400 && !empty($hdr['location'])) {
                $url = $hdr['location'];
                continue;
            }

            if ($code !== 200) {
                throw new \RuntimeException('ответ ' . $code . ' на ' . $url);
            }

            return (string) $body;
        }

        throw new \RuntimeException('слишком много переадресаций');
    }

    /** Ставим только пакет выпуска: манифест pkg_*.xml с packagename vrknewsfeed_…, скриптом установки и без чужих расширений */
    private function checkPackage(string $zip, string $element): void
    {
        $z = new \ZipArchive();

        if ($z->open($zip) !== true) {
            throw new \RuntimeException('архив пакета не открывается');
        }

        $man = null;

        for ($i = 0; $i < $z->numFiles; $i++) {
            $n = (string) $z->getNameIndex($i);

            if (str_contains($n, '..') || str_starts_with($n, '/')) {
                throw new \RuntimeException('недопустимый путь в архиве: ' . $n);
            }

            if (preg_match('#^pkg_[^/]+\.xml$#', $n)) {
                $man = $n;
            }
        }

        $xml = $man ? (string) $z->getFromName($man) : '';
        $z->close();

        if (!preg_match('#<extension[^>]+type="package"#', $xml) || !preg_match('#<packagename>([^<]+)</packagename>#', $xml, $pm)
            || 'vrknewsfeed_' . preg_replace('/^vrknewsfeed_/', '', trim($pm[1])) !== $element || !str_contains($xml, '<scriptfile>')) {
            throw new \RuntimeException('в архиве нет манифеста пакета выпуска ' . $element);
        }

        // дочерним расширением допускается только набор снимков выпуска: file_vrknewsfeed_ГГГГММДД[NN]
        preg_match_all('#<(file|folder)\b([^>]*)>#', preg_match('#<files[^>]*>(.*?)</files>#s', $xml, $fm) ? $fm[1] : '', $kids, PREG_SET_ORDER);

        foreach ($kids as $kid) {
            if ($kid[1] !== 'file' || !preg_match('#type="file"#', $kid[2]) || !preg_match('#id="file_' . preg_quote($element, '#') . '"#', $kid[2])) {
                throw new \RuntimeException('пакет несёт расширение, кроме снимков выпуска: по команде такие пакеты не ставятся');
            }
        }
    }

    private function audit(string $text): void
    {
        Log::add($text, Log::INFO, 'vrkfeed-remote');
    }

    private function rjson(int $code, array $data): void
    {
        $app = $this->getApplication();
        $app->setHeader('Status', (string) $code, true);
        $this->json($data);
    }

    /** Страница хода установки */
    private function page(string $pkg, array $job): void
    {
        $app   = $this->getApplication();
        $pause = max(0, min(60, (int) $this->params->get('pause', 2))) * 1000;
        $step  = Uri::base() . 'index.php?option=com_ajax&group=ajax&plugin=vrkfeed&format=raw&act=step&pkg=' . $pkg . '&' . Session::getFormToken() . '=1';
        $total = \count($job['data']['items']);
        $next  = (int) $job['next'];
        $done  = !empty($job['done']) ? 'true' : 'false';
        $issue = htmlspecialchars((string) $job['issue']);
        $back  = Uri::base() . 'index.php?option=com_content&view=articles';
        $inst  = Uri::base() . 'index.php?option=com_installer&view=install';
        $cfg   = json_encode(['step' => $step, 'pause' => $pause, 'total' => $total, 'next' => $next, 'done' => !empty($job['done'])]);
        $app->setHeader('Content-Type', 'text/html; charset=utf-8', true);
        $app->setHeader('Cache-Control', 'no-store', true);
        $app->sendHeaders();
        echo <<<HTML
<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Выпуск {$issue}: поэтапная установка</title>
<style>
body{font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;margin:0;background:#f4f6f9;color:#1c2733}
main{max-width:760px;margin:32px auto;padding:24px;background:#fff;border-radius:10px;box-shadow:0 1px 4px rgba(0,0,0,.08)}
h1{font-size:20px;margin:0 0 4px}.sub{color:#5a6775;margin:0 0 20px}
.bar{height:14px;background:#e3e8ee;border-radius:7px;overflow:hidden}.bar i{display:block;height:100%;width:0;background:#2a69b8;transition:width .4s}
.st{margin:10px 0 16px;font-weight:600}#log{max-height:360px;overflow:auto;border-top:1px solid #e3e8ee;padding-top:8px;font-size:13px}
#log div{padding:2px 0}#log .err{color:#b3261e}#log .ok{color:#1d6b35}
.btn{display:inline-block;margin:16px 8px 0 0;padding:8px 14px;border-radius:6px;background:#2a69b8;color:#fff;text-decoration:none;border:0;font:inherit;cursor:pointer}
.btn.g{background:#e3e8ee;color:#1c2733}[hidden]{display:none}
</style></head><body><main>
<h1>Выпуск {$issue}: поэтапная установка</h1>
<p class="sub">Материалы ставятся по одному, с паузой, чтобы сайт не подвисал. Страницу можно не закрывать до конца; если закрыли — откройте снова, установка продолжится с того же места.</p>
<div class="bar"><i id="bar"></i></div>
<div class="st" id="st"></div>
<button class="btn" id="go" hidden>Продолжить</button>
<a class="btn g" id="arts" href="{$back}" hidden>К материалам</a>
<a class="btn g" href="{$inst}">К установке расширений</a>
<div id="log"></div>
</main>
<script>
(function(){
  var c={$cfg}, k=c.next, tries=0, bar=document.getElementById('bar'), st=document.getElementById('st'), log=document.getElementById('log'), go=document.getElementById('go');
  function line(t,cls){var d=document.createElement('div');d.textContent=t;if(cls)d.className=cls;log.appendChild(d);log.scrollTop=log.scrollHeight;}
  function show(){bar.style.width=Math.round(100*Math.min(k,c.total)/c.total)+'%';st.textContent='Материалов: '+Math.min(k,c.total)+' из '+c.total;}
  function stop(t){line(t,'err');go.hidden=false;}
  function finish(){bar.style.width='100%';st.textContent='Готово: материалов '+c.total+' из '+c.total+'.';document.getElementById('arts').hidden=false;}
  function next(){
    go.hidden=true;
    fetch(c.step,{credentials:'same-origin',cache:'no-store'}).then(function(r){return r.json();}).then(function(j){
      if(j.busy){setTimeout(next,c.pause||1500);return;}
      (j.messages||[]).forEach(function(m){line(m,j.error?'err':'');});
      if(j.fatal||j.error){stop('Остановлено. Исправьте причину и нажмите «Продолжить».');return;}
      tries=0;k=j.k;show();
      if(j.done){line('Установка выпуска завершена.','ok');finish();return;}
      if(j.title)line('№'+String(k).padStart(2,'0')+' поставлен: '+j.title,'ok');
      setTimeout(next,c.pause);
    }).catch(function(e){
      tries++;
      if(tries<=3){line('Сбой связи, повтор через '+(c.pause/1000+2)+' с ('+tries+' из 3)…','err');setTimeout(next,c.pause+2000);}
      else stop('Сервер не ответил три раза подряд.');
    });
  }
  go.onclick=function(){tries=0;next();};
  show();
  if(c.done){line('Этот выпуск уже установлен полностью.','ok');finish();}else{line('Начинаем с материала '+(k+1)+' из '+c.total+'.');next();}
})();
</script>
</body></html>
HTML;
        $app->close();
    }
}
